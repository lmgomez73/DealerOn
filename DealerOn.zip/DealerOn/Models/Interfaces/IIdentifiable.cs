﻿namespace DealerOn.Models.Interfaces
{
    public interface IIdentifiable
    {
        int Id { get; set; }
    }
}
