﻿namespace DealerOn.Models.Interfaces
{
    public interface ITaxable
    {
        double Tax { get; }
    }
}
