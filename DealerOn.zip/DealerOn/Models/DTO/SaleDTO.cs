﻿namespace DealerOn.Models.DTO
{
    public class SaleDTO
    {
        public int[] ProductsIds { get; set; }

    }
}
