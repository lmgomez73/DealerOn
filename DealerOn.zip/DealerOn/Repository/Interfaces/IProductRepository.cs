﻿using DealerOn.Models.Interfaces;

namespace DealerOn.Repository.Interfaces
{
    public interface IProductRepository : IGenericRepository<IProduct>
    {

    }
}
