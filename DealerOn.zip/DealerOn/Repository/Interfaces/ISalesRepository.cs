﻿using DealerOn.Models.Interfaces;

namespace DealerOn.Repository.Interfaces
{
    public interface ISalesRepository : IGenericRepository<ISale>
    {
    }
}
