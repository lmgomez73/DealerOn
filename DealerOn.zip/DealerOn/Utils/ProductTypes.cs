﻿namespace DealerOn.Utils
{
    public enum ProductTypes
    {
        FOOD,
        MEDICAL,
        BOOK,
        OTHER
    }
}
